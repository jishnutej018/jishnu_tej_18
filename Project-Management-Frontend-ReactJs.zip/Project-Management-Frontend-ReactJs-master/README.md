# Project-Management-Frontend-ReactJs

Frontend branch for project management application.
This branch consists of client side code for project management application, Using ReactJs(ES6). Material UI theme for UX.
We use npm package manager, bable and webpack in this application.
Implemented flux, used react router in this application.


All you need to do is take a pull fron this repo and run npm install to get all node modules file, And run npm run watch to compile the code and start working.
