// var BASEURL = 'http://13.76.39.209:8081/';
// var BASEURL = 'http://13.67.61.36:8087/';
// var BASEURL = 'http://192.168.4.21:8000/';
// var BASEURL = 'http://192.168.3.129:8001/'; //farhan's local server
// var BASEURL = 'http://192.168.3.156:8000/'; //utkarsh's local server
// var BASEURL = 'http://192.168.3.134:8000/'; //anuja's local server
// var BASEURL = 'https://a5fe1e4c.ngrok.io/';
// var BASEURL = 'http://happayv2.southeastasia.cloudapp.azure.com:8083/';
// var BASEURL = 'http://192.168.3.133:9001/'; // abhishek's local server
var BASEURL = 'http://127.0.0.1:8000/'; // back-end development
// var BASEURL = 'http://52.77.239.108:8010/'; //test team back-end latest
// var BASEURL = 'http://api-v2.happay.in/';
// var BASEURL = 'http://873fdb14.ngrok.io/';
export default BASEURL;